package tannu.assignment1;


public class EggMain {

	public static void main(String[] args) {
		CalculateEggs e = new CalculateEggs();
		String a = e.getTotalNoOfEggs();
		
	    System.out.println(a);
	}

}
