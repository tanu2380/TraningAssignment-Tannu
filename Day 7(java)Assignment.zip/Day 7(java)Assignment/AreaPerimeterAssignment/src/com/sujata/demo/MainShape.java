package com.sujata.demo;

public class MainShape {

	public static void main(String[] args) {
		Shape shape=new Shape();

		shape.perimeter(7, 5);
		shape.perimeter(8);
		shape.area(7, 5);
		shape.area(8);
		
	}

}
