package tannu.assignment.com;

public class HeightOfPerson {
		
		private int feet, inch;
		
		public HeightOfPerson(int feet, int inch) {
			this.feet = feet;
			if(inch > 12) {
				this.feet += (inch / 12);
				this.inch = inch%12;
			}
		}
		
		public void displayHeight() {
			System.out.println("Height is "+this.feet + " feet "+ this.inch+ " inch.");
		}
	}

