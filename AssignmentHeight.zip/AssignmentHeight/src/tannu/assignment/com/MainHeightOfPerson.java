package tannu.assignment.com;

public class MainHeightOfPerson {


		public static void main(String[] args) {
			HeightOfPerson height = new HeightOfPerson(6,17);
			height.displayHeight();

		}

	}

