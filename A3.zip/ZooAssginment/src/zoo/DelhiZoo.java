package zoo;
import org.animals.*;

public class DelhiZoo {
	public static void main(String[] args){
        Deer d = new Deer();
        Lion l = new Lion();
        Tiger t = new Tiger();
        d.Details();
        l.Details();
        t.Details();
    }

}
