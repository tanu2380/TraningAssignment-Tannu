package tannu.assignment;

public class Main {
	public static void main(String args[]) {
	DailyWorker d=new DailyWorker(28,"Tannu",70);
	SalariedWorker s=new SalariedWorker(67,"Ranveer",99);
	d.compay(45);
	s.compay();
	}
}
