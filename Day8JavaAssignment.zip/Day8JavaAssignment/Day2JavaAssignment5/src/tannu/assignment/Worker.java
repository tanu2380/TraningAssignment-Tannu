package tannu.assignment;

/*
Exercise 5:Create a class called Worker. Write classes DailyWorker and SalariedWorker that inherit from
Worker.Every worker has a name and a salaryrate. Write method Pay (int hours) to compute 
the week pay of every worker.  A Daily worker is paid on the basis of the number of days 
she/he works.The salaried worker gets paid the wage for 40 hours a week no matter what the
actual hours are.  Test this program to calculate the pay of workers. 

*/

public class Worker {
	String name;
	int empno;
	
	Worker(int no,String n) { 
		empno=no; name=n; 
	}
	
	void show() {
		System.out.println("\n=============================");
		System.out.println("Employee Number : "+empno);
		System.out.println("Employee Name : "+name);
	}
}

class DailyWorker  extends Worker {
	int rate;
	
	DailyWorker (int no,String n,int r) {
		super(no,n);
		rate=r;
	}
	
	void compay(int h) {
		show();
		System.out.println("Salary : "+rate*h);
	}
}
	
class SalariedWorker extends Worker {

	int rate;
	
	SalariedWorker(int no,String n,int r) {
		super(no,n);
		rate=r;
	}
	
	int hour=40;
	
	void compay() {
		show();
		System.out.println("Salary : "+rate*hour);
	}
}


