package com.tannu.assignment;

abstract public class Shape3D {
	
	abstract public double volume();
	abstract public double surfaceArea();


}
