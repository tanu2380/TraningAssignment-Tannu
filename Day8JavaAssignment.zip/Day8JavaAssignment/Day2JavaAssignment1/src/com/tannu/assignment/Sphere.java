package com.tannu.assignment;
/*Exercise 1:Create a class called Shape3D with the following method signatures alone, volume () and 
surfaceArea (). Then create subclasses like Cylinder, Sphere, and Cube etc and implement 
these methods.*/



public class Sphere extends Shape3D {
	private int r;
	
	public Sphere(int r) {
		this.r=r;
	}
	
	public double volume() {
		return (4.0 / 3) * Math.PI * r * r * r;
	}
	
	public double surfaceArea() {
		return 4 * Math.PI * r * r;
	}
}
